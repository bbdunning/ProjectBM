
Program 4
=====

## CONTROLS ##

### View: ###
    * The view is controlled by movement of the mouse.
    * Mouse cursor icon is disabled via glfw command (hopfully does not create any cross compatibility errors)

### Movement: ###
    * W and S dolley the camera forward and backward
    * A and D strafe the camera
    * Space raised the camera
    * LeftCtrl lowers the camera
    * LeftShift increases movement speed

### Misc: ###
    * Q and E move the light left and right along the X axis.


## Status Report ##
All features implemented
Code is very messy, dont judge me. I'll refactor during the final project :)

skybox downloaded from https://opengameart.org